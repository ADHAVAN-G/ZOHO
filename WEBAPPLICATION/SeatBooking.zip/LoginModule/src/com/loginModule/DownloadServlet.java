package com.loginModule;

import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

@WebServlet("/download")
public class DownloadServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		String id=request.getParameter("id");
		int subId=Integer.parseInt(id.substring(8,id.length()));
		
		try {
			java.sql.Connection con=JDBC.initialize();
			Statement st1=con.createStatement();
			String query="select name,mobilenumber,client.entryemail,amount,seatNumber,client.id from client inner join receipt on client.loginemail=receipt.loginemail and client.id=receipt.id and client.loginemail='"+session.getAttribute("username")+"' and receipt.id="+subId+"";
			ResultSet rs1=st1.executeQuery(query);
			rs1.next();
			
			String file=rs1.getString(1)+"-"+rs1.getString(3)+"-"+rs1.getInt(6)+".pdf";
			String outputfile=System.getProperty("user.home")+"\\Downloads\\"+file;
			
			String answer="RECEIPT\n";
			answer+="Name = "+rs1.getString(1)+"\n";
			answer+="Mobilenumber = "+rs1.getString(2)+"\n";
			answer+="Email = "+rs1.getString(3)+"\n";
			answer+="Amount = "+rs1.getInt(4)+"\n";
			answer+="seat number = "+rs1.getString(5);
			Document doc=new Document();
			
			PdfWriter writer=PdfWriter.getInstance(doc,new FileOutputStream(outputfile));
			doc.open();
			Paragraph para=new Paragraph(answer);
			doc.add(para);
			doc.close();
			writer.close();
			
			SendGmail send=new SendGmail();
			send.sendMail("adhavansurya18@gmail.com","adhav1405",rs1.getString(3), file, outputfile);
			RequestDispatcher rd=request.getRequestDispatcher("DownloadAlert.jsp");
			rd.forward(request, response);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}
