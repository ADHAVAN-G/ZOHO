package com.loginModule;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import java.util.Properties;
public class SendGmail {
	void sendMail(String sender,String password,String receipient,String file,String outputfile) {        
		
        Properties prop = new Properties();
		prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true");
        
        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(sender, password);
                    }
                });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(sender));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(receipient)
            );
            message.setSubject("RedBus");
            message.setText("Ticket");
            MimeBodyPart messageBodyPart2 = new MimeBodyPart();  
            
            DataSource source = new FileDataSource(outputfile);  
            messageBodyPart2.setDataHandler(new DataHandler(source));  
            messageBodyPart2.setFileName(file);  
             
                  
            Multipart multipart = new MimeMultipart();    
            multipart.addBodyPart(messageBodyPart2);  
          
            message.setContent(multipart);  
            Transport.send(message);

        } catch (MessagingException e) {
            e.printStackTrace();
        }
	}
}
