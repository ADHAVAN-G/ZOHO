package com.loginModule;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SeatOperation {
	Connection con=null;
	protected ArrayList<Integer> getSeats(){
		ArrayList<Integer>SeatDetails=null;
		try {
			con = JDBC.initialize();
			SeatDetails=new ArrayList();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from seatdetails where bookedseat=(select max(bookedseat) from seatdetails)");
			rs.next();
			SeatDetails.add(rs.getInt(1));
			SeatDetails.add(rs.getInt(2));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SeatDetails;
	}
	
	protected void Seat(int start,int end,int male,int female){
		Connection con;
		PreparedStatement p = null;
		try {
			con = JDBC.initialize();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from seatInfo");
			int i=1;
			while(rs.next()) {
				if(rs.getInt(2)==-1 && i==start) {
					String sql=new String();
					if(male-->0)
						sql= "update seatInfo set seatstate=1,gender='male' where seatnumber="+rs.getInt(1)+"";
					else if(female-->0)
						sql= "update seatInfo set seatstate=1,gender='female' where seatnumber="+rs.getInt(1)+"";
					p = con.prepareStatement(sql);
					p.execute();
					start++;
					if(start>end)
						break;
				}
				i++;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	protected boolean SeatValidate(int start,HttpServletRequest request,HttpServletResponse response) {
		Connection con;
		PreparedStatement p = null;
		try {
			con = JDBC.initialize();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from seatInfo");
			int i=1;
			while(rs.next()) {
				if(start==i && rs.getInt(2)==1) {
					return true;
				}
				i++;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	protected int generateId(String email) {
		int id=1;
		try {
			Connection con=JDBC.initialize();
			Statement st=con.createStatement();
			String query="SELECT Id FROM client where loginemail='"+email+"' ORDER BY ID DESC LIMIT 1";
			ResultSet rs=st.executeQuery(query);
			if(rs.next()) {
				id=Integer.parseInt(rs.getString(1))+1;
			}
			else {
				return id;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return id;
	}
	
}
