package com.loginModule;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.regex.Pattern;

@WebServlet("/newPassword")
public class ResetPassword extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		try {
			Connection con=JDBC.initialize();
			String check_data="select * from createaccount";
			Statement st1=con.createStatement();
			ResultSet rs=st1.executeQuery(check_data);
			boolean flag=true;
			while(rs.next()) {
				if(rs.getString(2).equals(request.getParameter("email")))
					flag=false;
			}
			if(flag) {
				RequestDispatcher rd=request.getRequestDispatcher("NoEmailAlert.jsp");
				rd.forward(request, response);
			}
			if(!Pattern.matches("^[A-Za-z0-9+_-]+@[A-Za-z.-]+$",request.getParameter("email")) || !request.getParameter("pword").equals(request.getParameter("cpword"))) {
				RequestDispatcher rd=request.getRequestDispatcher("MissMatchPwordAlert.jsp");
				rd.forward(request, response);
			}
			Statement st2=con.createStatement();
			st2.executeUpdate("update createaccount set password='"+request.getParameter("cpword")+"'where email='"+request.getParameter("email")+"'");
			RequestDispatcher rd=request.getRequestDispatcher("PasswordSetAlert.jsp");
			rd.forward(request, response);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}
