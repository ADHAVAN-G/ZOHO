package com.loginModule;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/delete")
public class DeleteAccount extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		
		if(!Pattern.matches("^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@" 
				        + "[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$",email)) {
				RequestDispatcher rd=request.getRequestDispatcher("AccountCreateAlert.jsp");
				rd.forward(request,response);
			}
		try {
		Connection con=JDBC.initialize();
		String verify_data="select * from createAccount";
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery(verify_data);
		while(rs.next()) {
			if(rs.getString(2).equals(email)) {
				String delete_query="delete createaccount.*personaldetails.*,address.*,client.*,receipt.* from createaccount inner join client on createaccount.email=client.loginemail inner join  receipt on receipt.loginemail=client.loginemail inner join personaldetails on personaldetails.id=createaccount.id inner join address on createaccount.id=address.id where createaccount.email='"+email+"'";
				Statement st1=con.createStatement();
				st1.executeUpdate(delete_query);
				response.sendRedirect("DeleteAccountAlert.jsp");
			}
			rs.next();
		}
		response.sendRedirect("DeletedAccount.jsp");
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	
	}
}
