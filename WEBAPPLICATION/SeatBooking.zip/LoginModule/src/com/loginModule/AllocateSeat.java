package com.loginModule;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.Normalizer.Form;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

@WebServlet("/allocateSeat")
public class AllocateSeat extends HttpServlet {
	final int amount=100;
	
	synchronized protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		SeatOperation seatOp=new SeatOperation();
		PrintWriter out=response.getWriter();
		String name=request.getParameter("name");
		String mobile_number=request.getParameter("mobilenumber");
		String email=request.getParameter("email");
		String malecount=request.getParameter("malecount");
		String femalecount=request.getParameter("femalecount");
		session.setAttribute("email",email);
		
		ArrayList<String>Errors=new ArrayList();
		
		if(request.getParameter("ticketstart").equals("")||request.getParameter("ticketend").equals("")) {
			RequestDispatcher rd=request.getRequestDispatcher("Booking.jsp");
			rd.forward(request,response);
		}
		int start_range=Integer.parseInt(request.getParameter("ticketstart"));
		int end_range=Integer.parseInt(request.getParameter("ticketend"));
		
		if(seatOp.SeatValidate(start_range,request,response)) {
			Errors.add("you booked already booked seat");
		}
		if(name.equals(null)||name.length()<3||!Pattern.matches("[A-Za-z_]+",name))
				Errors.add("Enter the valid name");
		if(mobile_number.equals(null)||mobile_number.length()!=10||!Pattern.matches("\\d+",mobile_number))
			Errors.add("Enter valid Mobile number");
		if(email.equals(null)||!Pattern.matches("^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@"+ "[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$",email))
			Errors.add("Enter valid mail id");
		if(start_range>end_range)
			Errors.add("Enter valid range");
		if(malecount.equals(null)||femalecount.equals(null)||malecount.equals("")||
		femalecount.equals("")||(end_range-start_range+1)<(Integer.parseInt(malecount)+Integer.parseInt(femalecount)))
				Errors.add("Enter Valid count");
		
		session.setAttribute("errors",Errors);
		ArrayList<Integer>seatDetails=null;
		if(session.getAttribute("username")==null || session.getAttribute("password")==null
				||session.getAttribute("receipt")==null) {
			response.sendRedirect("Login.jsp");
		}
		else if(Errors.size()!=0) {
			RequestDispatcher rd=request.getRequestDispatcher("BookingAlert.jsp");
			rd.forward(request,response);
		}
		else {
			try {
				seatDetails=seatOp.getSeats();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
			int seat=seatDetails.get(0);
			int provide=seatDetails.get(1)+1;
			int required=end_range-start_range+1;
			
			if(required>seat) {
				String html="<html><h2> Available tickets="+seat+"</h2>"
						+"<form action=\"Booking.jsp\">"
						+ "<input type=\"submit\" value=\"Go to booking\">"
						+ "</form>"
						+ "</html>";
				out.println(html);
			}
			else {
				RequestDispatcher rd=request.getRequestDispatcher("Payment.jsp");
				ArrayList<String>seats=new ArrayList();
				int male=Integer.parseInt(request.getParameter("malecount"));
				int female=Integer.parseInt(request.getParameter("femalecount"));
				int id=seatOp.generateId((String)session.getAttribute("username"));
				
				for(int i=start_range;i<=end_range;i++)
					seats.add(String.valueOf(i));
				
				provide+=required;
				seat-=required;
				int total=required*amount;
				
				session.setAttribute("c_name",name);
				session.setAttribute("mobile_number",mobile_number);
				session.setAttribute("entryemail",email);
				session.setAttribute("s_id",id);
				session.setAttribute("malecount",malecount);
				session.setAttribute("femalecount",femalecount);
				session.setAttribute("remseat",seat);
				session.setAttribute("bookedseat",provide-1);
				session.setAttribute("amount",total);
				session.setAttribute("seatnumber",seats.toString());
				session.setAttribute("start",start_range);
				session.setAttribute("end",end_range);
				rd.forward(request, response);
			}
		}
	}
}
