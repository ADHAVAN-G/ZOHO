package com.loginModule;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

@WebServlet("/create")
public class CreateAccount extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int i=0;
		PrintWriter out=response.getWriter();
		
		String email=request.getParameter("email");
		
		if(!Pattern.matches("^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@" 
			        + "[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$",email)) {
			RequestDispatcher rd=request.getRequestDispatcher("AccountCreateAlert.jsp");
			rd.forward(request,response);
		}
		int id=-1;
		try {
			Connection con=JDBC.initialize();
			String verify_data="select * from createAccount";
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(verify_data);
			while(rs.next()) {
				if(rs.getString(2).equals(email)) {
					response.sendRedirect("CheckAccountAlert.jsp");
				}
				id=rs.getInt(1);
			}
			id+=1;
			String query1="insert into createAccount(id,email,password) values(?,?,?)";
			String query2="insert into personaldetails(id,firstname,middlename,lastname,dateofbirth,age,gender) values(?,?,?,?,?,?,?)";
			String query3="insert into address(id,doornumber,street,place,state,country,pincode) values(?,?,?,?,?,?,?)";
			PreparedStatement preparedStatement1 = con.prepareStatement(query1);
			PreparedStatement preparedStatement2 = con.prepareStatement(query2);
			PreparedStatement preparedStatement3 = con.prepareStatement(query3);
		      preparedStatement1.setInt(1,id);
		      preparedStatement1.setString(2,request.getParameter("email"));
		      preparedStatement1.setString(3,request.getParameter("password"));
		      preparedStatement2.setInt(1,id);
		      preparedStatement2.setString(2,request.getParameter("fname"));
		      preparedStatement2.setString(3,request.getParameter("mname"));
		      preparedStatement2.setString(4,request.getParameter("lname"));
		      preparedStatement2.setString(5,request.getParameter("dateOfBirth"));
		      preparedStatement2.setInt(6,Integer.parseInt(request.getParameter("age")));
		      preparedStatement2.setString(7,request.getParameter("gender"));
		      preparedStatement3.setInt(1,id);
		      preparedStatement3.setString(2,request.getParameter("d_number"));
		      preparedStatement3.setString(3,request.getParameter("streetnumber"));
		      preparedStatement3.setString(4,request.getParameter("place"));
		      preparedStatement3.setString(5,request.getParameter("state"));
		      preparedStatement3.setString(6,request.getParameter("country"));
		      preparedStatement3.setString(7,request.getParameter("pincode"));
		      i = preparedStatement1.executeUpdate();
		      preparedStatement2.executeUpdate();
		      preparedStatement3.executeUpdate();
		      if(i!=0) {
		    	  response.sendRedirect("CreateAccountAlert.jsp");
				}
				else {
					out.println("Error!!!");
				}
			
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
			out.println(e);
		}
	  
	}
}
