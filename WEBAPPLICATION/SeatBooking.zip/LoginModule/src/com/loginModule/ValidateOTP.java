package com.loginModule;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/validateOTP")
public class ValidateOTP extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//System.out.println(request.getParameter("Notp"));
		
		HttpSession session=request.getSession();
		//System.out.println(session.getAttribute("Rotp"));
		
		String rOTP=String.valueOf(session.getAttribute("Rotp"));
		String nOTP=String.valueOf(request.getParameter("Notp"));
		if(!rOTP.equals(nOTP))
		{
			GenerateOTP otp=new GenerateOTP();
			otp.doPost(request, response);
		}
		else {
			int start=(int)session.getAttribute("start");
			int end=(int)session.getAttribute("end");
			int male=Integer.parseInt((String) session.getAttribute("malecount"));
			int female=Integer.parseInt((String) session.getAttribute("femalecount"));
			RequestDispatcher rd=request.getRequestDispatcher("Receipt.jsp");
			try {
				String query1="insert into client(name,mobilenumber,LoginEmail,EntryEmail,Id,malecount,femalecount) values(?,?,?,?,?,?,?)";
				String query2="insert into seatdetails(remseat,bookedseat) values(?,?)";
				String query3="insert into receipt(LoginEmail,Id,amount,seatnumber) values(?,?,?,?)";

				Connection con=JDBC.initialize();
				PreparedStatement preparedStatement1 = con.prepareStatement(query1);
				PreparedStatement preparedStatement2 = con.prepareStatement(query2);
				PreparedStatement preparedStatement3 = con.prepareStatement(query3);
			    preparedStatement1.setString(1,(String)session.getAttribute("c_name"));
			    preparedStatement1.setString(2,(String)session.getAttribute("mobile_number"));
			    preparedStatement2.setInt(1,(int)session.getAttribute("remseat"));
			    preparedStatement2.setInt(2,(int)session.getAttribute("bookedseat"));
			    preparedStatement3.setString(1,(String)session.getAttribute("username"));
			    preparedStatement3.setInt(2,(int)session.getAttribute("s_id"));
			    preparedStatement3.setInt(3,(int)session.getAttribute("amount"));
			    preparedStatement3.setString(4,(String)session.getAttribute("seatnumber"));
			    preparedStatement1.setString(3,(String)session.getAttribute("username"));
			    preparedStatement1.setString(4,(String)session.getAttribute("entryemail"));
			    preparedStatement1.setInt(5,(int)session.getAttribute("s_id"));
			    preparedStatement1.setInt(6,male);
			    preparedStatement1.setInt(7,female);
			    preparedStatement1.executeUpdate();
			    preparedStatement2.executeUpdate();
			    preparedStatement3.executeUpdate();
			} 
			catch (Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
			SeatOperation seatOp=new SeatOperation();
			
			seatOp.Seat(start,end,male,female);
			rd.forward(request, response);
		}
	}

}